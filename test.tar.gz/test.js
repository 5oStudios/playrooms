function main() {
  console.log('Hello, world!');
  return 'Hello, world!';
}
main();
